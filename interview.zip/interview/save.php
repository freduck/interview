<?php

$link=mysqli_connect('localhost','brigidw2_books','FATHERFATHEr@1','brigidw2_bincom_test');
$p=$_POST['polingname'];
$pn=$_POST['pname'];
$r=$_POST['res'];
$sql=mysqli_query($link,"INSERT INTO new_polling (polling_unit_name, pname,result)VALUES('$p','$pn','$r')");
if($sql){
	echo "Result added";
}else{
echo mysqli_error($link);
}
?>