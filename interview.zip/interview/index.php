<!DOCTYPE html>
<html>
<body>
<link rel="stylesheet" href="bootstrap.min.css">
<link rel="stylesheet" href="tailwind.min.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
	<!-- <script type="text/javascript" src="js/bootstrap.min.js"></script> -->
<!-- <script src="js/jquery-1.11.2.min.js"></script> -->
<!-- <script src="jquery.validate.min.js"></script> -->
</script>
<!-- <script src="toastr.js"></script></script> -->
<!-- <link rel="stylesheet" href="toastr.min.css"> -->
<div class="container">
<div class="col-md-6 m-auto" style="margin-left:30%;margin-top:5%;">
    <h2 class=''>Question 1</h2>
  <h3>Enter Polling Unit Id</h3>
<form id="f" enctype="multipart/form-data" class="d-flex">
    <input type="text" name="poling" class="form-control" style="width:200px;" id="p">
    <!-- <input type="button" id="search" value="Search"> -->
</form><br/>
<div class="shadow-md border-2" id= "result" style="display: none;"></div>


<br/>
    <h2 class=''>Question 2</h2>
 
<form id="c" enctype="multipart/form-data" class="d-flex">
    <h3>Select a local government</h3>
    <select name="lga"  class="form-control custom-select " required id="lga" style="width: 100px;">
      <option></option>
<?php


$link=mysqli_connect('localhost','brigidw2_books','FATHERFATHEr@1','brigidw2_bincom_test');
$sql=mysqli_query($link,"SELECT  * from lga");
while($row=mysqli_fetch_assoc($sql)){

?>
<option value="<?php echo $row['lga_name'];?>"><?php echo $row['lga_name'];?></option>
<?php
}
?>
</select>
    <!-- <input type="button" id="search" value="Search"> -->
</form><br/>
<div class="shadow-md border-2" id= "result1" style="display: none;" ></div>

<br/><br/>
  <h2 class=''>Question 3</h2><br/>
<a href="addresult.php" class="py-5 px-4 rounded bg-blue-600 text-white">Add Result</a>
<style>
.col-md-6{
	margin-top:10px;
}tr{
  padding-bottom: 10px;
}
</style>
</div></div>
<script type="text/javascript" src="add.js"></script>
	<script type="text/javascript">
	// toastr.options = {
 //            'closeButton': true,
 //            'debug': false,
 //            'newestOnTop': false,
 //            'progressBar': true,
 //            'positionClass': 'toast-top-right',  
 //            'preventDuplicates': false,
 //            'showDuration': '1000',
 //            'hideDuration': '1000',
 //            'timeOut': '5000',
 //            'extendedTimeOut': '1000',
 //            'showEasing': 'swing',
 //            'hideEasing': 'linear',
 //            'showMethod': 'fadeIn',
 //            'hideMethod': 'fadeOut',
 //        };
 $(document).ready(function(){

		$('#p').on('keyup',function(){
			var p=$("#p").val();
			
			// console.log(p);
      $.ajax({
        type:'POST',
        url:"individual_pol.php",
        data:'poling=' + p,
        success:function(d){
          $("#result").css("display","block");
          $("#result").html(d);
        }
      })
		});
  });
 $(document).ready(function(){
  $('#lga').on('change',function(){
      var q=$("#lga").val();
      
      // console.log(q);
      $.ajax({
        type:'POST',
        url:"local.php",
        data:'lga=' + q,
        success:function(b){
          $("#result1").css("display","block");
          $("#result1").html(b);
          // console.log(b);
        }
      })
    });
 })

   

	</script>

    
</script>
</body>
</html>