
<?php


$link=mysqli_connect('localhost','brigidw2_books','FATHERFATHEr@1','brigidw2_bincom_test');

	$lga=$_POST['lga'];
$sql=mysqli_query($link,"SELECT lga.lga_name,sum(announced_pu_results.party_score) AS score FROM announced_pu_results  JOIN lga ON announced_pu_results.polling_unit_uniqueid = lga.uniqueid WHERE lga.lga_name='$lga'");
echo "<table class='table table-borderless'><tr><th>Lga Name</th><th>Total Result</th></tr>";
if(mysqli_num_rows($sql)>0){
while ($row=mysqli_fetch_assoc($sql)) {
    if(empty($row['score'])){
      	echo "<p class='text-warning text-center'>Score Field Is Empty</p>";  
    }
	echo "<tr><td>". $row['lga_name']." </td><td>  ". $row['score']."</td></tr>";
}
}else{
	echo "<p class='text-danger text-center'>No Result Found</p>";
}
echo "</table>";

?>

