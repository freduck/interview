<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <link rel="stylesheet" href="bootstrap.min.css">
<link rel="stylesheet" href="tailwind.min.css">
<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/toastr.min.js"></script></script>
<link rel="stylesheet" href="toastr.min.css">
  <div class="container">
    <div class="col-md-6 m-auto" style="margin-left:30%;margin-top:5%;">
    <form  id="addform">
  <div class="form-group">
    <label >Party Name</label>
  <select name="pname" class="form-control" id="pname">
    <option></option>
<?php


$link=mysqli_connect('localhost','brigidw2_books','FATHERFATHEr@1','brigidw2_bincom_test');
$sql=mysqli_query($link,"SELECT  * from party");
while($row=mysqli_fetch_assoc($sql)){

?>
<option value="<?php echo $row['partyname'];?>"><?php echo $row['partyname'];?></option>
<?php
}
?>
  </select>
    
  </div>
  <div class="form-group ">
    <label>Party Result</label>
  <input type="text" name="res" class="form-control" id="presult">
</div>
<div class="form-group">
  <label>Polling Unit Name</label>
  <select class="form-control custom-select" style="width: 100px;" name="polingname" id="polingname">
          <option></option>
<?php

$link=mysqli_connect('localhost','brigidw2_books','FATHERFATHEr@1','brigidw2_bincom_test');
$sql=mysqli_query($link,"SELECT  * from polling_unit");
while($row=mysqli_fetch_assoc($sql)){

?>
<option value="<?php echo $row['polling_unit_name'];?>"><?php echo $row['polling_unit_name'];?></option>
<?php
}
?>
  </select>
</div>

<div class="form-group">
  <button class="btn btn-primary rounded" id="add">Save Result</button>
</div>
</form>
  </div>
</div>

<script src="js/jquery-1.11.2.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script type="text/javascript">
   toastr.options = {
            'closeButton': true,
            'debug': false,
            'newestOnTop': false,
            'progressBar': true,
            'positionClass': 'toast-top-right',  
            'preventDuplicates': false,
            'showDuration': '1000',
            'hideDuration': '1000',
            'timeOut': '5000',
            'extendedTimeOut': '1000',
            'showEasing': 'swing',
            'hideEasing': 'linear',
            'showMethod': 'fadeIn',
            'hideMethod': 'fadeOut',
        };
   $("#addform").submit(function(e){
    e.preventDefault();
  // alert("hi");
      $.ajax({
        method:'POST',
        url:'save.php',
        data:$(this).serialize(),
        success:function(resp){
         toastr.success(resp);
         setTimeout(function(){
          window.location='index.php';
         },5000);
        }
      })
      
    })
  
</script>
</body>
</html>