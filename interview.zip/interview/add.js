 $("#add").on('click',function(){
      var res=$('#presult').val();
      var pname=$('#pname').val();
      var polingname=$('#polingname').val();
      $.ajax({
        type:'POST',
        url:'save.php',
        data:'pname=' +pname +'&res='+res+ '&polingname='+polingname,
        success:function(resp){
         console.log(resp);
        }
      })
      
    })
  