<?php


$link=mysqli_connect('localhost','brigidw2_books','FATHERFATHEr@1','brigidw2_bincom_test');

	$polin_unique=$_POST['poling'];
$sql=mysqli_query($link,"SELECT  * from announced_pu_results where polling_unit_uniqueid='$polin_unique'");
echo "<table class='table table-borderless'><tr><th>Party  Name</th><th>Party Score</th></tr>";
if(mysqli_num_rows($sql)>0){
while ($row=mysqli_fetch_assoc($sql)) {
	echo "<tr><td>". $row['party_abbreviation']." </td><td>  ". $row['party_score']."</td></tr>";;
}
echo "</table>";
}else{
	echo "<p class='text-danger'>No Result Found</p>";
}

?>